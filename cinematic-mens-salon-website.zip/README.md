# SHARP CUTS® — Premium Men's Salon & Grooming Studio

A cinematic, motion-first website for a modern men's salon, built with
Next.js (App Router) · TypeScript · Tailwind CSS · Framer Motion ·
Drizzle ORM + PostgreSQL · Lucide icons.

> **Your style. Your statement.** — Precision cuts. Refined grooming.

---

## Quick start

```bash
npm install
npm run dev          # local development
npm run build        # production build
npm run start        # serve the production build
```

PostgreSQL is expected at `DATABASE_URL` (see `.env`). Apply the schema with:

```bash
npx drizzle-kit push
```

---

## ⚙ Owner setup — everything editable lives in ONE place

### `src/data/salon.ts` (brand, contact, hours, booking rules)

| Setting | Status | What to do |
| --- | --- | --- |
| `whatsappNumber` | **Placeholder** `REPLACE_WITH_SALON_WHATSAPP_NUMBER` | Enter the salon's real WhatsApp number, digits only with country code (e.g. `919876543210`). Until then the site honestly shows "to be added" states and the floating chat button stays hidden in production. |
| `phoneDisplay` / `phoneHref` | Empty | Real public phone number. |
| `email` | Empty | Public email (optional). |
| `instagram` | Empty | Full Instagram profile URL. |
| `addressLines` | Empty | Real street address lines. Until set, the site renders "Salon address to be added" — never a fake address or fake map. |
| `mapsUrl` | Empty | Google Maps share link → enables the GET DIRECTIONS button. |
| `siteUrl` | Empty | Production domain → enables canonical URLs, OG URLs and the sitemap. |
| `heroStatusLabel` | Empty | Optional verified one-liner in the hero (e.g. location · hours). |
| `openingHours` | Editable schedule | Update to the salon's real hours; `open/close: null` = weekly closing day. |
| `slotIntervalMinutes`, `minLeadMinutes`, `maxAdvanceDays` | 60 / 60 / 30 | Booking grid behaviour. |
| `barberSelection` | Disabled | Set `enabled: true` + list real barbers to offer a preferred-barber field. |

### `src/data/services.ts` — the service menu
Names, descriptions, durations and prices in one list. The services section,
booking form and footer all read from it.
**The prices shipped (`₹99–₹599`) are illustrative samples** — the site says
so wherever they appear. Replace with the verified price list before launch.

### `src/data/lookbook.ts` — the style gallery
Properly licensed Pexels photography, honestly labelled on-site as
*illustrative style inspiration — not customer photographs*. Swap in real
salon photography when available.

---

## Booking flow — how it actually works

1.  Visitor fills in name, phone (Indian format: 10-digit mobile, optional
    `+91`), service, date and time. Past dates are rejected the client side
    **and** the server side.
2.  Time slots are generated from the editable opening hours in
    `salon.ts`; slots already taken are fetched from the database and
    disabled (`GET /api/appointments?date=…`).
3.  `POST /api/appointments` re-validates everything, prevents slot
    conflicts (pre-check **+** a partial unique index for the race), and is
    idempotent via a browser-generated `clientToken`, so double-taps never
    create duplicates.
4.  The request is persisted with status `requested` and a reference code
    (e.g. `SC-9F3K2A`) is shown with a full summary.
5.  The visitor taps **SEND REQUEST VIA WHATSAPP** — a correctly
    URL-encoded `wa.me` deep link with all the details.
6.  The UI always states clearly: **a request is not a confirmed appointment
    until the salon replies.**

### Database

Table: `appointments` (see `src/db/schema.ts`)

- `status` lifecycle: `requested` → `confirmed` | `cancelled` (managed by the
  salon; a salon-side admin UI is a documented next step, not claimed here).
- Partial unique index on `(date, time)` where `status <> 'cancelled'`
  prevents double-booked active slots.
- Unique `client_token` makes submissions idempotent.
- Cancellation/rescheduling rules and salon-side management screens are
  intentionally **not** built yet — wire them up before advertising them.

---

## What's implemented

- [x] Cinematic hero with autoplaying muted looping video, poster/fallback,
      data-saver + `prefers-reduced-motion` awareness, staggered headline,
      subtle scroll parallax
- [x] Scroll-aware navbar (transparent → blurred), active-section highlight,
      animated mobile menu with Escape/scroll-lock/focus handling
- [x] Editorial brand statement with asymmetric parallax imagery
- [x] Service menu as an editorial index (not cards) with sticky hover visual,
      one data source, sample-price disclaimers, book-this-service preselection
- [x] Lookbook with working category filters, layout-animated grid, loading
      placeholders, graceful image fallbacks, honest inspiration disclaimer
- [x] Why-choose-us values — genuine standards, zero invented claims
- [x] Split-screen experience section with parallax
- [x] Honest "Customer stories, coming soon" block (no fabricated reviews)
- [x] Full booking system: validation → DB persistence → summary → WhatsApp
      handoff; conflict prevention, duplicate protection, availability feed
- [x] Contact section with honest placeholder states + editable hours table
- [x] Floating WhatsApp button (dev setup warning until configured)
- [x] SEO basics: metadata, OG tags, robots, conditional sitemap
- [x] Accessibility: semantic landmarks, labelled controls, `role="alert"`
      errors, visible focus, keyboard-safe menus, reduced-motion everywhere

## What needs the real salon

- WhatsApp number, phone, address, maps link, email, Instagram, domain
- Verified price list, real opening hours, barber list (optional)
- Real customer reviews (the section renders "coming soon" until supplied)
- Real salon/team photography to replace stock inspiration

## What requires further backend work (not claimed as done)

- Salon-side appointment management UI (confirm / cancel / reschedule)
- Customer-facing cancellation or rescheduling flows
- Notification emails/SMS

---

## Photography & video credits

All imagery/video is from Pexels creators (free to use): Kelly, Antoni
Shkraba, cottonbro studio, Sự Minh, Alexander Mass, Kerim Isazade, Rahib
Hamidov, Ryan Klaus, Alex Urezkov, Josue Velasquez, Geancarlo Peruzzolo,
Michael Obstoj, Brian Silva, Maria Orlova, Murat Gökçe, Farhan Alkhaled and
Tima Miroshnichenko. Used as illustrative inspiration only.
