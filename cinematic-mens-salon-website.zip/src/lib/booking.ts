/**
 * Booking domain logic — shared by the client form and the API route so
 * validation rules live in exactly one place.
 */
import { salon } from "@/data/salon";

/* ── Types ─────────────────────────────────────────────────────────────── */

export interface AppointmentPayload {
  name: string;
  phone: string;
  serviceId: string;
  barber?: string;
  date: string; // "YYYY-MM-DD"
  time: string; // "HH:MM" 24h
  notes?: string;
  clientToken?: string; // idempotency / duplicate-submission protection
}

export type FieldErrors = Partial<Record<string, string>>;

/* ── Phone validation (India: 10-digit mobile, optional +91) ───────────── */

const PHONE_PATTERN = /^(?:\+?91[\s-]?)?[6-9]\d{9}$/;

export function isValidPhone(raw: string): boolean {
  return PHONE_PATTERN.test(raw.trim());
}

/* ── Date / slot helpers ───────────────────────────────────────────────── */

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;

/** Local "YYYY-MM-DD" — avoids the UTC shift of toISOString(). */
export function toDateInputValue(d: Date): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/** Parse "YYYY-MM-DD" as a LOCAL date (never UTC-shifted). */
export function parseLocalDate(dateStr: string): Date | null {
  if (!DATE_RE.test(dateStr)) return null;
  const [y, m, d] = dateStr.split("-").map(Number);
  const dt = new Date(y, m - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d
    ? dt
    : null;
}

export const WEEKDAYS = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
] as const;

export function openingForDate(dateStr: string) {
  const dt = parseLocalDate(dateStr);
  if (!dt) return null;
  return salon.openingHours.find((h) => h.day === WEEKDAYS[dt.getDay()]) ?? null;
}

function toMinutes(hhmm: string): number {
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
}

/**
 * All bookable start times for a date, honouring the salon's opening hours,
 * slot interval, same-day lead time and weekly closing day.
 */
export function generateSlots(dateStr: string, now = new Date()): string[] {
  const day = openingForDate(dateStr);
  if (!day || !day.open || !day.close) return [];
  const start = toMinutes(day.open);
  const end = toMinutes(day.close);
  const step = salon.slotIntervalMinutes;
  const isToday = dateStr === toDateInputValue(now);
  const earliest = isToday
    ? now.getHours() * 60 + now.getMinutes() + salon.minLeadMinutes
    : 0;

  const slots: string[] = [];
  for (let t = start; t + step <= end; t += step) {
    if (isToday && t < earliest) continue;
    const h = String(Math.floor(t / 60)).padStart(2, "0");
    const m = String(t % 60).padStart(2, "0");
    slots.push(`${h}:${m}`);
  }
  return slots;
}

/* ── Display formatting ────────────────────────────────────────────────── */

export function formatSlotLabel(hhmm: string): string {
  const [h, m] = hhmm.split(":").map(Number);
  const period = h >= 12 ? "PM" : "AM";
  const hour = h % 12 === 0 ? 12 : h % 12;
  return `${hour}:${String(m).padStart(2, "0")} ${period}`;
}

export function formatDateLabel(dateStr: string): string {
  const dt = parseLocalDate(dateStr);
  if (!dt) return dateStr;
  return dt.toLocaleDateString("en-IN", {
    weekday: "short",
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

/* ── Validation (used by both the form and the API) ────────────────────── */

export function validateAppointment(
  p: AppointmentPayload,
  opts: { serviceIds: string[] },
  now = new Date(),
): FieldErrors {
  const errors: FieldErrors = {};

  const name = p.name?.trim() ?? "";
  if (name.length < 2 || name.length > 60) {
    errors.name = "Please enter your full name (2–60 characters).";
  }

  if (!isValidPhone(p.phone ?? "")) {
    errors.phone = `Enter a valid ${salon.phoneHint}.`;
  }

  if (!opts.serviceIds.includes(p.serviceId)) {
    errors.service = "Please choose a service.";
  }

  const date = parseLocalDate(p.date ?? "");
  if (!date) {
    errors.date = "Choose a valid date.";
  } else {
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const max = new Date(today);
    max.setDate(max.getDate() + salon.maxAdvanceDays);
    if (date < today) errors.date = "Past dates can't be booked.";
    else if (date > max)
      errors.date = `Bookings open up to ${salon.maxAdvanceDays} days ahead.`;
  }

  if (!TIME_RE.test(p.time ?? "")) {
    errors.time = "Choose a time slot.";
  } else if (!errors.date) {
    const slots = generateSlots(p.date, now);
    if (!slots.includes(p.time)) {
      errors.time = "That time isn't available for the selected date.";
    }
  }

  if (salon.barberSelection.enabled) {
    const barber = p.barber?.trim() ?? "";
    if (barber && !salon.barberSelection.barbers.includes(barber)) {
      errors.barber = "Please choose a listed barber.";
    }
  }

  if ((p.notes ?? "").length > 500) {
    errors.notes = "Please keep notes under 500 characters.";
  }

  return errors;
}

/* ── WhatsApp deep links ───────────────────────────────────────────────── */

export interface RequestSummary {
  reference: string;
  name: string;
  phone: string;
  serviceName: string;
  barber?: string;
  date: string;
  time: string;
  notes?: string;
}

/** Correctly URL-encoded wa.me deep link. */
export function buildWhatsAppLink(message: string): string {
  return `https://wa.me/${salon.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

export function buildAppointmentMessage(s: RequestSummary): string {
  const lines = [
    `Hello ${salon.name}, I'd like to request an appointment.`,
    ``,
    `Reference: ${s.reference}`,
    `Name: ${s.name}`,
    `Phone: ${s.phone}`,
    `Service: ${s.serviceName}`,
    s.barber ? `Preferred barber: ${s.barber}` : null,
    `Date: ${formatDateLabel(s.date)}`,
    `Time: ${formatSlotLabel(s.time)}`,
    s.notes ? `Notes: ${s.notes}` : null,
    ``,
    `(Reference ${s.reference} — sent from the website request form.)`,
  ];
  return lines.filter((l): l is string => l !== null).join("\n");
}

export function summaryAsPlainText(s: RequestSummary): string {
  return buildAppointmentMessage(s);
}
