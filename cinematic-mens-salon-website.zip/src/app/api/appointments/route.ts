import { and, eq, ne } from "drizzle-orm";
import { NextRequest } from "next/server";
import { db } from "@/db";
import { appointments } from "@/db/schema";
import { services } from "@/data/services";
import {
  generateSlots,
  parseLocalDate,
  validateAppointment,
  type AppointmentPayload,
} from "@/lib/booking";

export const dynamic = "force-dynamic";

function reference(): string {
  return `SC-${crypto.randomUUID().replace(/-/g, "").slice(0, 6).toUpperCase()}`;
}

/**
 * GET /api/appointments?date=YYYY-MM-DD
 * Returns the times already taken for that date so the form can disable them.
 */
export async function GET(req: NextRequest) {
  const dateStr = req.nextUrl.searchParams.get("date") ?? "";
  if (!parseLocalDate(dateStr)) {
    return Response.json({ error: "Invalid date." }, { status: 400 });
  }
  try {
    const rows = await db
      .select({ time: appointments.time })
      .from(appointments)
      .where(
        and(
          eq(appointments.date, dateStr),
          ne(appointments.status, "cancelled"),
        ),
      );
    return Response.json({ booked: rows.map((r) => r.time) });
  } catch (err) {
    console.error("[appointments:GET]", err);
    return Response.json(
      { error: "Availability is unavailable right now." },
      { status: 500 },
    );
  }
}

/**
 * POST /api/appointments
 * Validates + persists an appointment REQUEST with:
 *  · server-side re-validation (same rules as the client)
 *  · slot conflict prevention (pre-check + unique index race guard)
 *  · duplicate submission protection (idempotent client token)
 */
export async function POST(req: NextRequest) {
  let body: AppointmentPayload;
  try {
    body = (await req.json()) as AppointmentPayload;
  } catch {
    return Response.json({ error: "Invalid request body." }, { status: 400 });
  }

  const errors = validateAppointment(body, {
    serviceIds: services.map((s) => s.id),
  });
  if (Object.keys(errors).length > 0) {
    return Response.json({ error: "validation", fields: errors }, { status: 400 });
  }

  const clientToken =
    typeof body.clientToken === "string" && body.clientToken.length <= 64
      ? body.clientToken
      : null;

  try {
    // 1) Idempotency: a retried submission returns the original request.
    if (clientToken) {
      const existing = await db
        .select({ reference: appointments.reference })
        .from(appointments)
        .where(eq(appointments.clientToken, clientToken))
        .limit(1);
      if (existing.length > 0) {
        return Response.json({ ok: true, reference: existing[0].reference, duplicate: true });
      }
    }

    // 2) Slot must still be within the generated schedule (defence in depth).
    if (!generateSlots(body.date).includes(body.time)) {
      return Response.json(
        { error: "slot_unavailable", fields: { time: "That time isn't available for the selected date." } },
        { status: 409 },
      );
    }

    // 3) Conflict check, then insert. The partial unique index protects the
    //    race between check and insert.
    const clash = await db
      .select({ id: appointments.id })
      .from(appointments)
      .where(
        and(
          eq(appointments.date, body.date),
          eq(appointments.time, body.time),
          ne(appointments.status, "cancelled"),
        ),
      )
      .limit(1);
    if (clash.length > 0) {
      return Response.json(
        { error: "slot_taken", fields: { time: "That slot was just taken — please pick another time." } },
        { status: 409 },
      );
    }

    const ref = reference();
    await db.insert(appointments).values({
      reference: ref,
      clientToken,
      name: body.name.trim(),
      phone: body.phone.trim(),
      service: body.serviceId,
      barber: body.barber?.trim() || null,
      date: body.date,
      time: body.time,
      notes: body.notes?.trim() || null,
      status: "requested",
    });

    return Response.json({ ok: true, reference: ref });
  } catch (err) {
    // Unique-index race → someone else claimed the slot a moment ago.
    if (err instanceof Error && /appointments_active_slot_unique/.test(err.message)) {
      return Response.json(
        { error: "slot_taken", fields: { time: "That slot was just taken — please pick another time." } },
        { status: 409 },
      );
    }
    console.error("[appointments:POST]", err);
    return Response.json(
      { error: "server", message: "Something went wrong while saving your request. Please try again." },
      { status: 500 },
    );
  }
}
