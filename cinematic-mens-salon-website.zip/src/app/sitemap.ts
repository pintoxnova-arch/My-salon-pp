import type { MetadataRoute } from "next";
import { salon } from "@/data/salon";

/**
 * The sitemap is only published once the salon's real domain is configured
 * in src/data/salon.ts (`siteUrl`) — we never publish fake canonical URLs.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  if (!salon.siteUrl) return [];
  return [
    {
      url: salon.siteUrl,
      lastModified: new Date(),
      changeFrequency: "monthly",
      priority: 1,
    },
  ];
}
