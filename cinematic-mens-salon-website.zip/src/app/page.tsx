import { BookingProvider } from "@/components/booking-context";
import Navbar from "@/components/navbar";
import Hero from "@/components/hero";
import Marquee from "@/components/marquee";
import BrandStatement from "@/components/brand-statement";
import ServicesSection from "@/components/services-section";
import LookbookSection from "@/components/lookbook-section";
import WhyChooseUs from "@/components/why-choose-us";
import Experience from "@/components/experience";
import Testimonials from "@/components/testimonials";
import BookingSection from "@/components/booking-section";
import ContactSection from "@/components/contact-section";
import Footer from "@/components/footer";
import WhatsAppButton from "@/components/whatsapp-button";

export default function Home() {
  return (
    <BookingProvider>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:bg-champagne focus:px-4 focus:py-2 focus:text-xs focus:font-semibold focus:uppercase focus:tracking-widest focus:text-ink"
      >
        Skip to content
      </a>
      <Navbar />
      <main id="main">
        <Hero />
        <Marquee />
        <BrandStatement />
        <ServicesSection />
        <LookbookSection />
        <WhyChooseUs />
        <Experience />
        <Testimonials />
        <BookingSection />
        <ContactSection />
      </main>
      <Footer />
      <WhatsAppButton />
    </BookingProvider>
  );
}
