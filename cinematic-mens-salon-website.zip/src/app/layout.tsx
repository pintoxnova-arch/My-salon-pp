import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Bebas_Neue, Manrope } from "next/font/google";
import { salon } from "@/data/salon";
import "./globals.css";

const bebas = Bebas_Neue({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-bebas",
  display: "swap",
});

const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-manrope",
  display: "swap",
});

/**
 * Canonical + absolute Open Graph URLs are only emitted once the real domain
 * is configured in src/data/salon.ts — never fake metadata.
 */
export const metadata: Metadata = {
  ...(salon.siteUrl ? { metadataBase: new URL(salon.siteUrl) } : {}),
  title: salon.metaTitle,
  description: salon.metaDescription,
  openGraph: {
    title: salon.metaTitle,
    description: salon.metaDescription,
    type: "website",
    siteName: salon.nameWithMark,
  },
};

export const viewport: Viewport = {
  themeColor: "#080808",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${bebas.variable} ${manrope.variable}`}>
      <body className="bg-ink text-bone font-sans antialiased">{children}</body>
    </html>
  );
}
