import { sql } from "drizzle-orm";
import {
  date,
  index,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

/**
 * Appointment requests.
 *
 * A row represents a REQUEST, never a confirmed booking — the salon confirms
 * manually (e.g. via WhatsApp). `status` lifecycle, managed by the salon:
 *   "requested" → "confirmed" | "cancelled"
 */
export const appointments = pgTable(
  "appointments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    /** Short human-friendly reference shared with the customer, e.g. SC-9F3K2A. */
    reference: text("reference").notNull().unique(),
    /** Idempotency token from the browser — protects against double submits. */
    clientToken: text("client_token"),
    name: text("name").notNull(),
    phone: text("phone").notNull(),
    service: text("service").notNull(),
    barber: text("barber"),
    date: date("date", { mode: "string" }).notNull(), // "YYYY-MM-DD"
    time: text("time").notNull(), // "HH:MM" 24h salon-local time
    notes: text("notes"),
    status: text("status").notNull().default("requested"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [
    // One active appointment per slot. Cancelled rows free the slot again.
    uniqueIndex("appointments_active_slot_unique")
      .on(t.date, t.time)
      .where(sql`status <> 'cancelled'`),
    uniqueIndex("appointments_client_token_unique").on(t.clientToken),
    index("appointments_date_idx").on(t.date),
  ],
);
