/**
 * ─────────────────────────────────────────────────────────────────────────
 *  SHARP CUTS® — CENTRAL SALON CONFIGURATION
 * ─────────────────────────────────────────────────────────────────────────
 *  This is the SINGLE SOURCE OF TRUTH for the salon's identity, contact
 *  details, opening hours and booking behaviour. Replace every value marked
 *  with [SETUP] before going live. Nothing on the site invents business
 *  details: empty / placeholder values render honest "to be added" states.
 * ─────────────────────────────────────────────────────────────────────────
 */

export const salon = {
  /* ── Brand ─────────────────────────────────────────────────────────── */
  name: "SHARP CUTS",
  nameWithMark: "SHARP CUTS®",
  tagline: "YOUR STYLE. YOUR STATEMENT.",
  supportingLine:
    "Precision cuts. Refined grooming. A better version of your everyday style.",

  /* ── SEO / metadata ────────────────────────────────────────────────── */
  metaTitle: "SHARP CUTS® — Premium Men's Salon & Grooming Studio",
  metaDescription:
    "SHARP CUTS is a premium men's salon and grooming studio. Precision haircuts, skin fades, beard styling and grooming packages. Request your appointment online.",
  // [SETUP] Full production domain, e.g. "https://www.sharpcutsalon.com".
  // Leave empty until the real domain is known — canonical URLs, Open Graph
  // URLs and the sitemap stay disabled instead of publishing fake ones.
  siteUrl: "",

  /* ── Contact details — [SETUP] replace the placeholders ───────────── */
  // WhatsApp number in international format, digits only (country code first),
  // e.g. "919876543210". Used for booking requests + the floating chat button.
  // Until a real number is entered, the site will NOT send visitors anywhere —
  // it shows an honest "not configured" state instead.
  whatsappNumber: "REPLACE_WITH_SALON_WHATSAPP_NUMBER",
  whatsappInquiryMessage:
    "Hello SHARP CUTS! I'd like to ask about your services and availability.",

  // [SETUP] Public phone number, e.g. display "+91 98765 43210", href "+919876543210".
  phoneDisplay: "",
  phoneHref: "",

  // [SETUP] Public email, e.g. "hello@sharpcutsalon.com". Empty = hidden.
  email: "",

  // [SETUP] Full Instagram profile URL, e.g. "https://instagram.com/sharpcuts".
  instagram: "",

  // [SETUP] Real street address lines, e.g. ["12, MG Road", "Bengaluru 560001"].
  // Empty renders an honest "Salon address to be added" state — never a fake.
  addressLines: [] as string[],

  // [SETUP] Google Maps share / directions URL for the real location.
  mapsUrl: "",

  // Optional short line shown in the hero (e.g. "MG Road · Open Tue–Sun").
  // Only rendered when filled in with verified information.
  heroStatusLabel: "",

  /* ── Phone validation locale ───────────────────────────────────────── */
  // Currently tuned for India (10-digit mobile, optional +91 prefix).
  countryDialCode: "+91",
  phoneHint: "10-digit mobile number",

  /* ── Opening hours — editable schedule ─────────────────────────────── */
  // open/close use 24h "HH:MM". Set both to null for a weekly closing day.
  // NOTE: these are the salon's own editable hours — update them to reality.
  openingHours: [
    { day: "Monday", open: null, close: null },
    { day: "Tuesday", open: "10:00", close: "20:00" },
    { day: "Wednesday", open: "10:00", close: "20:00" },
    { day: "Thursday", open: "10:00", close: "20:00" },
    { day: "Friday", open: "10:00", close: "20:00" },
    { day: "Saturday", open: "10:00", close: "21:00" },
    { day: "Sunday", open: "10:00", close: "18:00" },
  ] as { day: string; open: string | null; close: string | null }[],

  /* ── Booking rules ─────────────────────────────────────────────────── */
  slotIntervalMinutes: 60, // distance between bookable start times
  minLeadMinutes: 60, // same-day slots must start at least this far ahead
  maxAdvanceDays: 30, // how far ahead requests are accepted

  /* ── Barber selection ──────────────────────────────────────────────── */
  // [SETUP] Set enabled to true and list the real barbers to offer a
  // "preferred barber" field in the booking form. Off by default.
  barberSelection: {
    enabled: false,
    barbers: [] as string[],
  },
} as const;

/** True only when a plausible real WhatsApp number has been configured. */
export function isWhatsAppConfigured(): boolean {
  return /^[1-9]\d{7,14}$/.test(salon.whatsappNumber);
}

/** True when at least one real address line has been configured. */
export function hasAddress(): boolean {
  return salon.addressLines.length > 0;
}

export type OpeningDay = (typeof salon.openingHours)[number];
