/**
 * ─────────────────────────────────────────────────────────────────────────
 *  LOOKBOOK — STYLE GALLERY DATA
 * ─────────────────────────────────────────────────────────────────────────
 *  Images are properly licensed photography from Pexels and are presented
 *  honestly as ILLUSTRATIVE STYLE INSPIRATION. They are not, and must not
 *  be presented as, photographs of this salon's actual customers.
 *  Replace with real salon photography when available.
 * ─────────────────────────────────────────────────────────────────────────
 */

export const lookbookCategories = [
  "All Styles",
  "Fade",
  "Textured",
  "Classic",
  "Curly",
  "Beard",
] as const;

export type LookbookCategory = (typeof lookbookCategories)[number];

export interface LookbookItem {
  id: string;
  title: string;
  category: Exclude<LookbookCategory, "All Styles">;
  image: string;
  alt: string;
  /** Larger tile in the editorial grid. */
  featured?: boolean;
}

const img = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800`;

export const lookbookItems: LookbookItem[] = [
  {
    id: "skin-fade",
    title: "Skin Fade",
    category: "Fade",
    image: img(33461079),
    alt: "Barber blending a precise skin fade with clipper and comb.",
    featured: true,
  },
  {
    id: "classic-taper",
    title: "Classic Taper",
    category: "Classic",
    image: img(12304510),
    alt: "Close-up of a clean classic tapered haircut in a barbershop.",
  },
  {
    id: "curly-top",
    title: "Curly Top",
    category: "Curly",
    image: img(16791412),
    alt: "Studio portrait of a man wearing a confident curly top style.",
  },
  {
    id: "textured-crop",
    title: "Textured Crop",
    category: "Textured",
    image: img(12464845),
    alt: "Barber cutting a textured crop with scissors over comb.",
  },
  {
    id: "beard-sculpt",
    title: "Beard Sculpt",
    category: "Beard",
    image: img(9992819),
    alt: "Barber sculpting the lines of a client's full beard.",
  },
  {
    id: "low-fade",
    title: "Low Fade",
    category: "Fade",
    image: img(18503604),
    alt: "Clipper work detailing a low fade at the neckline.",
  },
  {
    id: "buzz-cut",
    title: "Buzz Cut",
    category: "Classic",
    image: img(39559325),
    alt: "Profile portrait of a man with a sharp buzz cut and beard.",
    featured: true,
  },
  {
    id: "natural-curls",
    title: "Natural Volume",
    category: "Curly",
    image: img(16577924),
    alt: "Moody portrait of a man with natural curls catching the light.",
  },
  {
    id: "high-taper",
    title: "High Taper",
    category: "Fade",
    image: img(33448215),
    alt: "Barber tapering the back of a client's head with a clipper.",
  },
  {
    id: "scissor-texture",
    title: "Scissor Texture",
    category: "Textured",
    image: img(4625626),
    alt: "Barber adding texture to a men's haircut in a modern studio.",
  },
  {
    id: "slick-back",
    title: "Slick Back",
    category: "Classic",
    image: img(31660408),
    alt: "Black and white portrait of a man with a slicked-back style.",
  },
  {
    id: "beard-detail",
    title: "Beard Detail",
    category: "Beard",
    image: img(4625621),
    alt: "Detailed beard trimming and styling at the barber's chair.",
  },
];

export const lookbookDisclaimer =
  "Style inspiration from professional grooming photography (Pexels). These are illustrative references — not customer photographs.";
