/**
 * ─────────────────────────────────────────────────────────────────────────
 *  SERVICE MENU — SINGLE EDITABLE DATA SOURCE
 * ─────────────────────────────────────────────────────────────────────────
 *  ⚠ The prices below are ILLUSTRATIVE SAMPLE PRICES ONLY. They are shown
 *  on the site together with a disclaimer and must be replaced with the
 *  salon's real, verified price list before launch.
 *  Add / remove / reorder services freely — the services section, the
 *  booking form and the footer all read from this one list.
 * ─────────────────────────────────────────────────────────────────────────
 */

export interface Service {
  id: string;
  name: string;
  description: string;
  /** Display string, e.g. "₹199". */
  price: string;
  duration: string;
  /** Editorial image shown beside the menu (Pexels, properly licensed). */
  image: string;
  imageAlt: string;
}

export const services: Service[] = [
  {
    id: "classic-haircut",
    name: "Classic Haircut",
    description:
      "A tailored haircut finished with attention to shape and detail.",
    price: "₹199",
    duration: "40 min",
    image:
      "https://images.pexels.com/photos/12464845/pexels-photo-12464845.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    imageAlt:
      "Barber refining a classic men's haircut with comb and scissors.",
  },
  {
    id: "skin-fade",
    name: "Skin Fade",
    description:
      "A clean, precise fade blended to suit your preferred look.",
    price: "₹299",
    duration: "45 min",
    image:
      "https://images.pexels.com/photos/33461079/pexels-photo-33461079.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    imageAlt:
      "Close-up of a barber blending a skin fade with clippers and comb.",
  },
  {
    id: "haircut-and-beard",
    name: "Haircut & Beard",
    description: "A coordinated haircut and beard grooming session.",
    price: "₹399",
    duration: "70 min",
    image:
      "https://images.pexels.com/photos/10024235/pexels-photo-10024235.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    imageAlt:
      "Barber finishing a bearded client's haircut with a brush.",
  },
  {
    id: "beard-styling",
    name: "Beard Styling",
    description: "Shape, define, and refine your beard.",
    price: "₹149",
    duration: "25 min",
    image:
      "https://images.pexels.com/photos/9992819/pexels-photo-9992819.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    imageAlt: "Barber shaping and defining a client's beard.",
  },
  {
    id: "wash-and-styling",
    name: "Hair Wash & Styling",
    description: "A refreshing wash and a polished everyday finish.",
    price: "₹99",
    duration: "25 min",
    image:
      "https://images.pexels.com/photos/33448217/pexels-photo-33448217.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    imageAlt: "Client enjoying a relaxing hair wash at the salon basin.",
  },
  {
    id: "premium-package",
    name: "Premium Grooming Package",
    description: "A customizable combination of grooming services.",
    price: "₹599",
    duration: "100 min",
    image:
      "https://images.pexels.com/photos/12339159/pexels-photo-12339159.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    imageAlt:
      "Vintage barber chair in a premium grooming studio interior.",
  },
];

/** Shown wherever prices appear — never imply these are verified prices. */
export const pricingDisclaimer =
  "All prices shown are illustrative sample prices. Final pricing and availability should be confirmed with the salon.";
