"use client";

import { Quote } from "lucide-react";
import { LineReveal, Reveal, SectionLabel } from "@/components/motion";

/**
 * CUSTOMER STORIES — intentionally empty until the salon supplies real,
 * verifiable reviews. No fabricated names, ratings or photos, ever.
 */
export default function Testimonials() {
  return (
    <section
      aria-labelledby="stories-heading"
      className="border-t border-line py-24 md:py-32"
    >
      <div className="mx-auto max-w-[1400px] px-5 md:px-10">
        <Reveal>
          <div className="relative overflow-hidden border border-line px-6 py-16 text-center md:px-12 md:py-24">
            <span
              aria-hidden="true"
              className="text-stroke-ghost pointer-events-none absolute inset-x-0 -top-8 select-none text-center font-display text-[18vw] leading-none"
            >
              VOICES
            </span>
            <div className="relative">
              <SectionLabel align="center">Customer Stories</SectionLabel>
              <h2
                id="stories-heading"
                className="mt-6 font-display text-[clamp(2.4rem,5vw,4.4rem)] leading-[0.95] tracking-[0.01em] text-bone"
              >
                <LineReveal lines={["REAL WORDS, COMING SOON."]} />
              </h2>
              <Reveal delay={0.15}>
                <Quote
                  className="mx-auto mt-8 size-7 text-champagne"
                  strokeWidth={1.5}
                  aria-hidden="true"
                />
                <p className="mx-auto mt-5 max-w-md text-[15px] leading-relaxed text-fog">
                  This space is reserved for genuine reviews from real clients.
                  No placeholders, no scripts — once our clients share their
                  experience, it lives here.
                </p>
              </Reveal>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
