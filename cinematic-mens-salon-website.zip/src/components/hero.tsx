"use client";

import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { salon } from "@/data/salon";
import { LineReveal } from "@/components/motion";

const VIDEO_HD =
  "https://videos.pexels.com/video-files/9737935/9737935-hd_1920_1080_24fps.mp4";
const VIDEO_SD =
  "https://videos.pexels.com/video-files/9737935/9737935-hd_1280_720_24fps.mp4";
const POSTER =
  "https://images.pexels.com/videos/9737935/haircut-9737935.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1080&w=1920";

export default function Hero() {
  const reduce = useReducedMotion();
  const sectionRef = useRef<HTMLElement>(null);
  const [allowVideo, setAllowVideo] = useState(false);
  const [videoFailed, setVideoFailed] = useState(false);
  const [videoSrc, setVideoSrc] = useState(VIDEO_HD);

  /**
   * Data-conscious behaviour: the video only loads when the user hasn't
   * asked for reduced motion and isn't on a data-saver connection. A
   * still image always renders underneath as poster/fallback.
   */
  useEffect(() => {
    if (reduce) return;
    const conn = (navigator as Navigator & { connection?: { saveData?: boolean } })
      .connection;
    if (conn?.saveData) return;
    setVideoSrc(window.innerWidth < 768 ? VIDEO_SD : VIDEO_HD);
    setAllowVideo(true);
  }, [reduce]);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end start"],
  });
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "14%"]);
  const contentY = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const contentOpacity = useTransform(scrollYProgress, [0, 0.75], [1, 0]);

  return (
    <section
      ref={sectionRef}
      id="home"
      aria-label="Introduction"
      className="relative flex min-h-svh flex-col justify-end overflow-hidden"
    >
      {/* ── Cinematic background ── */}
      <motion.div
        aria-hidden="true"
        style={reduce ? undefined : { y: bgY }}
        className="absolute inset-0 scale-[1.06]"
      >
        {/* Poster is always rendered underneath — hero never breaks. */}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={POSTER}
          alt=""
          fetchPriority="high"
          className="absolute inset-0 h-full w-full object-cover"
        />
        {allowVideo && !videoFailed && (
          <motion.video
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.4, ease: "easeOut" }}
            className="absolute inset-0 h-full w-full object-cover"
            src={videoSrc}
            poster={POSTER}
            autoPlay
            muted
            loop
            playsInline
            preload="metadata"
            onError={() => setVideoFailed(true)}
          />
        )}
        {/* Readability overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/45 to-ink/35" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink/70 via-transparent to-transparent" />
      </motion.div>

      {/* ── Content ── */}
      <motion.div
        style={reduce ? undefined : { y: contentY, opacity: contentOpacity }}
        className="relative z-10 mx-auto w-full max-w-[1400px] px-5 pb-24 pt-40 md:px-10 md:pb-28"
      >
        <motion.p
          initial={reduce ? false : { opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.35, ease: [0.22, 1, 0.36, 1] }}
          className="mb-6 flex items-center gap-3 text-[10px] font-semibold uppercase tracking-[0.4em] text-champagne md:text-[11px]"
        >
          <span className="h-px w-10 bg-champagne/70" aria-hidden="true" />
          The Modern Grooming Experience
        </motion.p>

        <h1 className="font-display text-[clamp(4.2rem,15vw,12.5rem)] leading-[0.86] tracking-[0.01em] text-bone">
          <LineReveal
            delay={0.45}
            stagger={0.11}
            lines={[
              "OWN",
              "YOUR",
              <>
                LOOK<span className="text-champagne">.</span>
              </>,
            ]}
          />
        </h1>

        <motion.p
          initial={reduce ? false : { opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.05, ease: [0.22, 1, 0.36, 1] }}
          className="mt-7 max-w-md text-[15px] leading-relaxed text-bone/75 md:text-base"
        >
          Precision grooming for men who care about the details.
        </motion.p>

        <motion.div
          initial={reduce ? false : { opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.2, ease: [0.22, 1, 0.36, 1] }}
          className="mt-10 flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-4"
        >
          <a
            href="#booking"
            className="inline-flex h-[52px] items-center justify-center bg-champagne px-9 text-[11px] font-bold uppercase tracking-[0.25em] text-ink transition-all duration-300 hover:bg-bone active:scale-[0.98]"
          >
            Book Your Chair
          </a>
          <a
            href="#services"
            className="inline-flex h-[52px] items-center justify-center border border-bone/25 px-9 text-[11px] font-bold uppercase tracking-[0.25em] text-bone transition-all duration-300 hover:border-champagne/70 hover:text-champagne active:scale-[0.98]"
          >
            Explore Our Services
          </a>
        </motion.div>

        {/* Only rendered once verified details are configured. */}
        {salon.heroStatusLabel && (
          <p className="mt-8 text-[11px] uppercase tracking-[0.3em] text-bone/60">
            {salon.heroStatusLabel}
          </p>
        )}
      </motion.div>

      {/* ── Scroll cue ── */}
      <motion.div
        initial={reduce ? false : { opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8, duration: 0.8 }}
        aria-hidden="true"
        className="absolute bottom-6 right-5 z-10 flex flex-col items-center gap-3 md:right-10"
      >
        <span className="text-[9px] font-semibold uppercase tracking-[0.4em] text-bone/50 [writing-mode:vertical-lr]">
          Scroll
        </span>
        <span className="relative h-12 w-px overflow-hidden bg-bone/15">
          <span className="absolute inset-x-0 h-full animate-scroll-cue bg-champagne" />
        </span>
      </motion.div>
    </section>
  );
}
