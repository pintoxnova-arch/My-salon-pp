import {
  Clock,
  Mail,
  MapPin,
  MessageCircle,
  Navigation,
  Phone,
} from "lucide-react";
import { InstagramIcon } from "@/components/icons";
import { hasAddress, isWhatsAppConfigured, salon } from "@/data/salon";
import { formatSlotLabel } from "@/lib/booking";
import { LineReveal, Reveal, SectionLabel } from "@/components/motion";

function ToBeAdded() {
  return (
    <span className="inline-flex items-center gap-2 border border-dashed border-line px-2.5 py-1 text-[10px] uppercase tracking-[0.22em] text-fog">
      To be added
    </span>
  );
}

export default function ContactSection() {
  const whatsappReady = isWhatsAppConfigured();
  const addressReady = hasAddress();

  return (
    <section
      id="contact"
      aria-labelledby="contact-heading"
      className="scroll-mt-20 border-t border-line py-24 md:py-36"
    >
      <div className="mx-auto max-w-[1400px] px-5 md:px-10">
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-16">
          {/* ── Details ── */}
          <div className="lg:col-span-7">
            <Reveal>
              <SectionLabel>Location & Contact</SectionLabel>
            </Reveal>
            <h2
              id="contact-heading"
              className="mt-6 font-display text-[clamp(3rem,7vw,6.2rem)] leading-[0.92] tracking-[0.01em] text-bone"
            >
              <LineReveal lines={["VISIT THE", "STUDIO."]} />
            </h2>

            <Reveal delay={0.12}>
              <dl className="mt-12 divide-y divide-line border-y border-line">
                {/* Address */}
                <div className="flex items-start gap-5 py-6">
                  <MapPin className="mt-1 size-5 shrink-0 text-champagne" strokeWidth={1.5} aria-hidden="true" />
                  <div className="flex flex-1 flex-wrap items-center justify-between gap-4">
                    <div>
                      <dt className="text-[10px] font-bold uppercase tracking-[0.28em] text-fog">Address</dt>
                      <dd className="mt-1.5 text-[15px] text-bone">
                        {addressReady ? (
                          salon.addressLines.map((line) => (
                            <span key={line} className="block">{line}</span>
                          ))
                        ) : (
                          <span className="text-fog">Salon address to be added</span>
                        )}
                      </dd>
                    </div>
                    {salon.mapsUrl ? (
                      <a
                        href={salon.mapsUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex h-11 items-center gap-2.5 border border-champagne/60 px-5 text-[10px] font-bold uppercase tracking-[0.25em] text-champagne transition-colors duration-300 hover:bg-champagne hover:text-ink"
                      >
                        <Navigation className="size-3.5" aria-hidden="true" />
                        Get Directions
                      </a>
                    ) : (
                      <ToBeAdded />
                    )}
                  </div>
                </div>

                {/* Phone */}
                <div className="flex items-start gap-5 py-6">
                  <Phone className="mt-1 size-5 shrink-0 text-champagne" strokeWidth={1.5} aria-hidden="true" />
                  <div className="flex flex-1 flex-wrap items-center justify-between gap-4">
                    <div>
                      <dt className="text-[10px] font-bold uppercase tracking-[0.28em] text-fog">Phone</dt>
                      <dd className="mt-1.5 text-[15px] text-bone">
                        {salon.phoneHref ? (
                          <a href={`tel:${salon.phoneHref}`} className="transition-colors hover:text-champagne">
                            {salon.phoneDisplay}
                          </a>
                        ) : (
                          <span className="text-fog">Phone number to be added</span>
                        )}
                      </dd>
                    </div>
                    {!salon.phoneHref && <ToBeAdded />}
                  </div>
                </div>

                {/* WhatsApp */}
                <div className="flex items-start gap-5 py-6">
                  <MessageCircle className="mt-1 size-5 shrink-0 text-champagne" strokeWidth={1.5} aria-hidden="true" />
                  <div className="flex flex-1 flex-wrap items-center justify-between gap-4">
                    <div>
                      <dt className="text-[10px] font-bold uppercase tracking-[0.28em] text-fog">WhatsApp</dt>
                      <dd className="mt-1.5 text-[15px] text-bone">
                        {whatsappReady ? (
                          <span className="text-fog">Chat with the studio directly</span>
                        ) : (
                          <span className="text-fog">WhatsApp number to be added</span>
                        )}
                      </dd>
                    </div>
                    {!whatsappReady && <ToBeAdded />}
                  </div>
                </div>

                {/* Email */}
                <div className="flex items-start gap-5 py-6">
                  <Mail className="mt-1 size-5 shrink-0 text-champagne" strokeWidth={1.5} aria-hidden="true" />
                  <div className="flex flex-1 flex-wrap items-center justify-between gap-4">
                    <div>
                      <dt className="text-[10px] font-bold uppercase tracking-[0.28em] text-fog">Email</dt>
                      <dd className="mt-1.5 text-[15px] text-bone">
                        {salon.email ? (
                          <a href={`mailto:${salon.email}`} className="transition-colors hover:text-champagne">
                            {salon.email}
                          </a>
                        ) : (
                          <span className="text-fog">Email to be added</span>
                        )}
                      </dd>
                    </div>
                    {!salon.email && <ToBeAdded />}
                  </div>
                </div>

                {/* Instagram */}
                <div className="flex items-start gap-5 py-6">
                  <InstagramIcon className="mt-1 size-5 shrink-0 text-champagne" />
                  <div className="flex flex-1 flex-wrap items-center justify-between gap-4">
                    <div>
                      <dt className="text-[10px] font-bold uppercase tracking-[0.28em] text-fog">Instagram</dt>
                      <dd className="mt-1.5 text-[15px] text-bone">
                        {salon.instagram ? (
                          <a
                            href={salon.instagram}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="transition-colors hover:text-champagne"
                          >
                            Follow the studio
                          </a>
                        ) : (
                          <span className="text-fog">Instagram profile to be added</span>
                        )}
                      </dd>
                    </div>
                    {!salon.instagram && <ToBeAdded />}
                  </div>
                </div>
              </dl>
            </Reveal>
          </div>

          {/* ── Opening hours ── */}
          <div className="lg:col-span-5">
            <Reveal delay={0.15}>
              <div className="border border-line bg-coal/50 p-7 md:p-9 lg:sticky lg:top-28">
                <div className="flex items-center gap-3">
                  <Clock className="size-5 text-champagne" strokeWidth={1.5} aria-hidden="true" />
                  <h3 className="font-display text-2xl tracking-[0.06em] text-bone">
                    OPENING HOURS
                  </h3>
                </div>
                <ul className="mt-7 space-y-0">
                  {salon.openingHours.map((day) => {
                    const closed = !day.open || !day.close;
                    return (
                      <li
                        key={day.day}
                        className={`flex items-baseline justify-between border-b border-line/60 py-3.5 last:border-b-0 ${
                          closed ? "text-fog/60" : "text-bone"
                        }`}
                      >
                        <span className="text-[12px] font-semibold uppercase tracking-[0.2em]">
                          {day.day}
                        </span>
                        <span
                          aria-hidden="true"
                          className="mx-4 flex-1 border-b border-dotted border-line/70"
                        />
                        <span className="text-sm tabular-nums">
                          {closed ? (
                            <span className="text-[11px] uppercase tracking-[0.25em]">Closed</span>
                          ) : (
                            `${formatSlotLabel(day.open!)} — ${formatSlotLabel(day.close!)}`
                          )}
                        </span>
                      </li>
                    );
                  })}
                </ul>
                <p className="mt-6 text-[12px] leading-relaxed text-fog/80">
                  Editable studio schedule — walk-ins and appointments follow
                  these hours. Confirm holiday timings with the salon.
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
