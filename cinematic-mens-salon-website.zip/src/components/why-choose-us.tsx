"use client";

import { MessagesSquare, Scissors, SlidersHorizontal, Sparkles } from "lucide-react";
import { LineReveal, Reveal, SectionLabel } from "@/components/motion";

/**
 * Genuine service standards — deliberately free of invented statistics,
 * rankings or awards.
 */
const FEATURES = [
  {
    icon: Scissors,
    title: "Precision & Attention to Detail",
    copy: "Every cut is finished with careful, deliberate work — lines, blends and edges included.",
  },
  {
    icon: MessagesSquare,
    title: "Personalized Style Consultation",
    copy: "We start with your head shape, hair type and routine — and agree on the look before the first cut.",
  },
  {
    icon: Sparkles,
    title: "Clean & Comfortable Environment",
    copy: "A tidy, well-kept studio with fresh tools and unhurried appointments.",
  },
  {
    icon: SlidersHorizontal,
    title: "Built Around Your Preferences",
    copy: "You set the brief. Subtle trim or full restyle — the service adapts to you, not the other way around.",
  },
];

export default function WhyChooseUs() {
  return (
    <section
      aria-labelledby="why-heading"
      className="border-t border-line py-24 md:py-36"
    >
      <div className="mx-auto max-w-[1400px] px-5 md:px-10">
        <div className="grid gap-8 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-8">
            <Reveal>
              <SectionLabel>Why Sharp Cuts</SectionLabel>
            </Reveal>
            <h2
              id="why-heading"
              className="mt-6 font-display text-[clamp(3rem,7vw,6.2rem)] leading-[0.92] tracking-[0.01em] text-bone"
            >
              <LineReveal lines={["A HIGHER STANDARD", "OF GROOMING."]} />
            </h2>
          </div>
          <Reveal delay={0.15} className="lg:col-span-4">
            <p className="max-w-xs text-[15px] leading-relaxed text-fog lg:ml-auto">
              No exaggerated promises. Just the standards we hold every single
              appointment to.
            </p>
          </Reveal>
        </div>

        <ul className="mt-16 grid gap-x-10 gap-y-12 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((feature, i) => (
            <Reveal key={feature.title} delay={0.08 * i}>
              <li className="group relative border-t border-line pt-7">
                <span
                  aria-hidden="true"
                  className="absolute -top-px left-0 h-px w-10 bg-champagne transition-all duration-500 group-hover:w-full"
                />
                <span className="flex items-center justify-between">
                  <feature.icon
                    className="size-6 text-champagne transition-transform duration-500 group-hover:-translate-y-1"
                    strokeWidth={1.5}
                    aria-hidden="true"
                  />
                  <span className="font-display text-lg tracking-[0.15em] text-fog/50">
                    0{i + 1}
                  </span>
                </span>
                <h3 className="mt-6 font-display text-[1.45rem] leading-tight tracking-[0.03em] text-bone">
                  {feature.title.toUpperCase()}
                </h3>
                <p className="mt-3 text-[13.5px] leading-relaxed text-fog">
                  {feature.copy}
                </p>
              </li>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  );
}
