"use client";

import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import GalleryImage from "@/components/gallery-image";
import { LineReveal, Reveal, SectionLabel } from "@/components/motion";

const IMG_BARBER =
  "https://images.pexels.com/photos/3998415/pexels-photo-3998415.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1400&w=1000";
const IMG_DETAIL =
  "https://images.pexels.com/photos/11333875/pexels-photo-11333875.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700";

const PRINCIPLES = [
  "A style consultation before every cut",
  "Clean execution, never rushed",
  "Honest advice on what suits you",
];

export default function Experience() {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const yMain = useTransform(scrollYProgress, [0, 1], [40, -40]);
  const yOverlay = useTransform(scrollYProgress, [0, 1], [100, -60]);

  return (
    <section
      ref={ref}
      id="about"
      aria-labelledby="about-heading"
      className="scroll-mt-20 overflow-hidden border-t border-line py-24 md:py-40"
    >
      <div className="mx-auto grid max-w-[1400px] items-center gap-16 px-5 md:px-10 lg:grid-cols-12 lg:gap-8">
        {/* Visual */}
        <div className="relative lg:col-span-6">
          <motion.div
            style={reduce ? undefined : { y: yMain }}
            className="relative w-[86%]"
          >
            <GalleryImage
              src={IMG_BARBER}
              alt="A barber carefully trimming a client's hair in a classic barbershop."
              className="aspect-[4/5] w-full"
            />
            <p
              aria-hidden="true"
              className="absolute -right-3 top-6 origin-right font-display text-6xl text-stroke-ghost [writing-mode:vertical-rl] md:text-7xl lg:-right-10"
            >
              EST. STYLE
            </p>
          </motion.div>
          <motion.div
            style={reduce ? undefined : { y: yOverlay }}
            className="absolute -bottom-12 right-0 w-[44%] max-w-[260px] md:-bottom-16"
          >
            <GalleryImage
              src={IMG_DETAIL}
              alt="Black and white close-up of trimmer detailing work."
              className="aspect-[3/4] w-full border-4 border-ink shadow-2xl shadow-black/60"
            />
          </motion.div>
        </div>

        {/* Copy */}
        <div className="lg:col-span-6 lg:pl-10">
          <Reveal>
            <SectionLabel>The Sharp Cuts Experience</SectionLabel>
          </Reveal>
          <h2
            id="about-heading"
            className="mt-6 font-display text-[clamp(3rem,6.5vw,5.8rem)] leading-[0.92] tracking-[0.01em] text-bone"
          >
            <LineReveal lines={["GOOD GROOMING.", "NO SHORTCUTS."]} />
          </h2>
          <Reveal delay={0.15}>
            <p className="mt-7 max-w-lg text-[15px] leading-relaxed text-fog md:text-base">
              Every appointment starts with understanding your preferred look.
              We focus on clean execution, thoughtful details, and a comfortable
              grooming experience — from the first conversation to the final
              mirror check.
            </p>
          </Reveal>
          <Reveal delay={0.22}>
            <ul className="mt-9 space-y-4">
              {PRINCIPLES.map((principle, i) => (
                <li key={principle} className="flex items-center gap-4">
                  <span className="text-[10px] font-bold tracking-[0.25em] text-champagne">
                    0{i + 1}
                  </span>
                  <span className="h-px w-6 bg-champagne/50" aria-hidden="true" />
                  <span className="text-sm text-bone/85">{principle}</span>
                </li>
              ))}
            </ul>
          </Reveal>
          <Reveal delay={0.3}>
            <a
              href="#booking"
              className="mt-11 inline-flex h-[52px] items-center justify-center border border-champagne/60 px-9 text-[11px] font-bold uppercase tracking-[0.25em] text-champagne transition-all duration-300 hover:bg-champagne hover:text-ink active:scale-[0.98]"
            >
              Book Your Chair
            </a>
            {/* A MEET THE TEAM block belongs here — added only when real team
                members and photos are supplied by the salon. */}
          </Reveal>
        </div>
      </div>
    </section>
  );
}
