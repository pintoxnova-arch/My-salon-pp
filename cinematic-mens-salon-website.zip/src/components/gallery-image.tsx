"use client";

import { useState } from "react";
import { ImageOff } from "lucide-react";

/**
 * Editorial image with a stable aspect box, a loading shimmer and an honest
 * fallback if the source ever fails — no broken-image icons, no layout shift.
 * The wrapper controls the aspect ratio / crop.
 */
export default function GalleryImage({
  src,
  alt,
  className = "",
  eager = false,
}: {
  src: string;
  alt: string;
  className?: string;
  eager?: boolean;
}) {
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        className={`flex items-center justify-center bg-coal ${className}`}
        role="img"
        aria-label={alt}
      >
        <span className="flex flex-col items-center gap-2 text-fog">
          <ImageOff className="size-5" aria-hidden="true" />
          <span className="text-[10px] uppercase tracking-[0.25em]">
            Image unavailable
          </span>
        </span>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden bg-coal ${className}`}>
      {!loaded && (
        <div
          className="absolute inset-0 animate-pulse-soft bg-[linear-gradient(110deg,#141414_30%,#1d1d1d_50%,#141414_70%)]"
          aria-hidden="true"
        />
      )}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={src}
        alt={alt}
        loading={eager ? "eager" : "lazy"}
        decoding="async"
        onLoad={() => setLoaded(true)}
        onError={() => setFailed(true)}
        className={`h-full w-full object-cover transition-[opacity,transform] duration-700 ease-out ${
          loaded ? "opacity-100" : "opacity-0"
        }`}
      />
    </div>
  );
}
