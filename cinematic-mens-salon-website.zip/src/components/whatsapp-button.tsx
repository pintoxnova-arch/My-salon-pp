"use client";

import { motion } from "framer-motion";
import { MessageCircle, Wrench } from "lucide-react";
import { isWhatsAppConfigured, salon } from "@/data/salon";
import { buildWhatsAppLink } from "@/lib/booking";

/**
 * Floating WhatsApp contact. Hidden entirely in production until a real
 * number is configured — in development it becomes a visible setup warning
 * instead of ever sending visitors to a fake number.
 */
export default function WhatsAppButton() {
  const configured = isWhatsAppConfigured();

  if (!configured) {
    if (process.env.NODE_ENV === "production") return null;
    return (
      <div
        role="status"
        className="fixed bottom-[calc(1.25rem+env(safe-area-inset-bottom))] right-5 z-40 flex max-w-[240px] items-start gap-2.5 border border-dashed border-champagne/50 bg-ink/90 p-3 backdrop-blur"
      >
        <Wrench className="mt-0.5 size-4 shrink-0 text-champagne" aria-hidden="true" />
        <p className="text-[10px] leading-relaxed tracking-wide text-fog">
          DEV — WhatsApp not configured. Set{" "}
          <code className="text-champagne">whatsappNumber</code> in{" "}
          <code className="text-champagne">src/data/salon.ts</code>.
        </p>
      </div>
    );
  }

  return (
    <motion.a
      href={buildWhatsAppLink(salon.whatsappInquiryMessage)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`Chat with ${salon.name} on WhatsApp`}
      initial={{ opacity: 0, scale: 0.6 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 2.2, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="fixed bottom-[calc(1.25rem+env(safe-area-inset-bottom))] right-5 z-40 grid size-14 place-items-center rounded-full bg-champagne text-ink shadow-lg shadow-black/50 transition-transform duration-300 hover:scale-105 focus-visible:scale-105 active:scale-95"
    >
      <MessageCircle className="size-6" aria-hidden="true" />
    </motion.a>
  );
}
