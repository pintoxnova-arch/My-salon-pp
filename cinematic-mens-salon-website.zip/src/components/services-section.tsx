"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { useState } from "react";
import { pricingDisclaimer, services } from "@/data/services";
import { useBooking } from "@/components/booking-context";
import GalleryImage from "@/components/gallery-image";
import { LineReveal, Reveal, SectionLabel } from "@/components/motion";

/**
 * The service menu — an editorial index, not a card grid. Each row preselects
 * the service and glides to the booking form. On desktop a sticky visual
 * crossfades to match the hovered service.
 */
export default function ServicesSection() {
  const { bookService } = useBooking();
  const [active, setActive] = useState(0);
  const current = services[active] ?? services[0];

  return (
    <section
      id="services"
      aria-labelledby="services-heading"
      className="scroll-mt-20 border-t border-line py-24 md:py-36"
    >
      <div className="mx-auto max-w-[1400px] px-5 md:px-10">
        {/* Header */}
        <div className="grid gap-8 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-7">
            <Reveal>
              <SectionLabel>Services & Pricing</SectionLabel>
            </Reveal>
            <h2
              id="services-heading"
              className="mt-6 font-display text-[clamp(3rem,7vw,6.2rem)] leading-[0.92] tracking-[0.01em] text-bone"
            >
              <LineReveal lines={["THE SERVICE", "MENU"]} />
            </h2>
          </div>
          <div className="lg:col-span-5">
            <Reveal delay={0.15}>
              <p className="max-w-sm text-[15px] leading-relaxed text-fog lg:ml-auto">
                Find the right service for your style — then request your chair
                in under a minute.
              </p>
              <p className="mt-4 inline-flex items-center gap-2 border border-line px-3 py-2 text-[10px] uppercase tracking-[0.25em] text-fog">
                <span className="size-1.5 rounded-full bg-champagne" aria-hidden="true" />
                Sample prices — illustrative
              </p>
            </Reveal>
          </div>
        </div>

        {/* Body */}
        <div className="mt-14 grid gap-12 lg:grid-cols-12 lg:gap-16">
          {/* Sticky visual (desktop) */}
          <div className="relative hidden lg:col-span-5 lg:block">
            <div className="sticky top-28">
              <div className="relative aspect-[4/5] overflow-hidden">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={current.id}
                    initial={{ opacity: 0, scale: 1.045 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                    className="absolute inset-0"
                  >
                    <GalleryImage
                      src={current.image}
                      alt={current.imageAlt}
                      className="h-full w-full"
                    />
                  </motion.div>
                </AnimatePresence>
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent"
                />
                <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between">
                  <div>
                    <p className="text-[10px] uppercase tracking-[0.3em] text-champagne">
                      {String(active + 1).padStart(2, "0")} — {current.duration}
                    </p>
                    <p className="mt-1 font-display text-3xl tracking-wide text-bone">
                      {current.name.toUpperCase()}
                    </p>
                  </div>
                </div>
              </div>
              <p aria-hidden="true" className="mt-4 text-right font-display text-7xl text-stroke-ghost">
                {String(services.length).padStart(2, "0")}
              </p>
            </div>
          </div>

          {/* The menu itself */}
          <div className="lg:col-span-7">
            <Reveal>
              <ul className="border-y border-line">
                {services.map((service, i) => (
                  <li key={service.id} className="border-b border-line last:border-b-0">
                    <button
                      type="button"
                      onClick={() => bookService(service.id)}
                      onMouseEnter={() => setActive(i)}
                      onFocus={() => setActive(i)}
                      aria-label={`Book ${service.name} — ${service.price}, ${service.duration}`}
                      className="group grid w-full grid-cols-[auto_1fr_auto] items-center gap-4 px-2 py-7 text-left transition-colors duration-300 hover:bg-coal/70 md:gap-8 md:px-6 md:py-8"
                    >
                      <span className="text-[11px] font-semibold tracking-[0.25em] text-fog transition-colors group-hover:text-champagne">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span>
                        <span className="block font-display text-[1.7rem] leading-none tracking-[0.03em] text-bone transition-colors duration-300 group-hover:text-champagne md:text-4xl">
                          {service.name.toUpperCase()}
                        </span>
                        <span className="mt-2 block max-w-md text-[13px] leading-relaxed text-fog">
                          {service.description}
                        </span>
                        <span className="mt-2 block text-[10px] uppercase tracking-[0.25em] text-fog/70">
                          {service.duration}
                        </span>
                      </span>
                      <span className="flex flex-col items-end gap-3">
                        <span className="font-display text-2xl tracking-wide text-bone md:text-3xl">
                          {service.price}
                        </span>
                        <span className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.25em] text-fog opacity-0 transition-all duration-300 group-hover:text-champagne group-hover:opacity-100 group-focus-visible:opacity-100 max-lg:hidden">
                          Book this service
                          <ArrowRight className="size-3.5 transition-transform duration-300 group-hover:translate-x-1" aria-hidden="true" />
                        </span>
                        <ArrowRight className="size-4 text-champagne lg:hidden" aria-hidden="true" />
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="mt-6 text-[12px] leading-relaxed text-fog/80">
                {pricingDisclaimer}
              </p>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
