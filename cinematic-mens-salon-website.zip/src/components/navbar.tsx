"use client";

import { AnimatePresence, motion, useMotionValueEvent, useScroll } from "framer-motion";
import { Menu, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { salon } from "@/data/salon";

const LINKS = [
  { label: "Home", href: "#home", id: "home" },
  { label: "Services", href: "#services", id: "services" },
  { label: "The Lookbook", href: "#lookbook", id: "lookbook" },
  { label: "About", href: "#about", id: "about" },
  { label: "Contact", href: "#contact", id: "contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<string>("home");
  const { scrollY } = useScroll();
  const menuButtonRef = useRef<HTMLButtonElement>(null);

  useMotionValueEvent(scrollY, "change", (v) => setScrolled(v > 32));

  /* Highlight the section currently in view. */
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) setActive(entry.target.id);
        }
      },
      { rootMargin: "-40% 0px -55% 0px" },
    );
    LINKS.forEach(({ id }) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  /* Mobile menu: scroll lock, Escape to close, focus return. */
  useEffect(() => {
    if (!open) return;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
      menuButtonRef.current?.focus();
    };
  }, [open]);

  return (
    <>
      <motion.header
        initial={{ y: -72, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.15 }}
        className={`fixed inset-x-0 top-0 z-50 transition-[background-color,border-color,backdrop-filter] duration-500 ${
          scrolled
            ? "border-b border-line bg-ink/85 backdrop-blur-md"
            : "border-b border-transparent bg-transparent"
        }`}
      >
        <nav
          aria-label="Primary"
          className="mx-auto flex h-16 max-w-[1400px] items-center justify-between px-5 md:h-20 md:px-10"
        >
          <a
            href="#home"
            className="font-display text-[1.65rem] leading-none tracking-[0.08em] text-bone transition-colors hover:text-champagne"
            aria-label={`${salon.nameWithMark} — back to top`}
          >
            {salon.name}
            <sup className="ml-0.5 align-super text-[0.55rem] text-champagne">®</sup>
          </a>

          {/* Desktop links */}
          <ul className="hidden items-center gap-9 lg:flex">
            {LINKS.map((link) => (
              <li key={link.id}>
                <a
                  href={link.href}
                  aria-current={active === link.id ? "true" : undefined}
                  className={`group relative py-2 text-[11px] font-semibold uppercase tracking-[0.28em] transition-colors duration-300 ${
                    active === link.id ? "text-bone" : "text-fog hover:text-bone"
                  }`}
                >
                  {link.label}
                  <span
                    aria-hidden="true"
                    className={`absolute -bottom-0.5 left-0 h-px bg-champagne transition-all duration-500 ${
                      active === link.id ? "w-full" : "w-0 group-hover:w-full"
                    }`}
                  />
                </a>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-3">
            <a
              href="#booking"
              className="hidden h-11 items-center bg-champagne px-6 text-[11px] font-bold uppercase tracking-[0.22em] text-ink transition-colors duration-300 hover:bg-bone sm:inline-flex"
            >
              Book an Appointment
            </a>
            <button
              ref={menuButtonRef}
              type="button"
              onClick={() => setOpen(true)}
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label="Open menu"
              className="grid size-11 place-items-center border border-line text-bone transition-colors duration-300 hover:border-champagne/60 hover:text-champagne lg:hidden"
            >
              <Menu className="size-5" aria-hidden="true" />
            </button>
          </div>
        </nav>
      </motion.header>

      {/* ── Mobile menu overlay ─────────────────────────────────────────── */}
      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            role="dialog"
            aria-modal="true"
            aria-label="Menu"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
            className="fixed inset-0 z-[60] flex flex-col bg-ink/97 backdrop-blur-xl lg:hidden"
          >
            <div className="flex h-16 items-center justify-between px-5">
              <span className="font-display text-[1.65rem] tracking-[0.08em] text-bone">
                {salon.name}
                <sup className="ml-0.5 align-super text-[0.55rem] text-champagne">®</sup>
              </span>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close menu"
                className="grid size-11 place-items-center border border-line text-bone transition-colors hover:border-champagne/60 hover:text-champagne"
              >
                <X className="size-5" aria-hidden="true" />
              </button>
            </div>

            <nav aria-label="Mobile" className="flex flex-1 flex-col justify-center px-8">
              <ul className="space-y-2">
                {LINKS.map((link, i) => (
                  <motion.li
                    key={link.id}
                    initial={{ opacity: 0, y: 28 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 12 }}
                    transition={{ delay: 0.08 + i * 0.06, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                  >
                    <a
                      href={link.href}
                      onClick={() => setOpen(false)}
                      className="group flex items-baseline gap-4 py-3"
                    >
                      <span className="text-[11px] font-semibold tracking-[0.3em] text-champagne/80">
                        0{i + 1}
                      </span>
                      <span
                        className={`font-display text-5xl leading-none tracking-[0.04em] transition-colors duration-300 group-hover:text-champagne ${
                          active === link.id ? "text-champagne" : "text-bone"
                        }`}
                      >
                        {link.label}
                      </span>
                    </a>
                  </motion.li>
                ))}
              </ul>
            </nav>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="px-8 pb-[calc(2rem+env(safe-area-inset-bottom))]"
            >
              <a
                href="#booking"
                onClick={() => setOpen(false)}
                className="flex h-14 items-center justify-center bg-champagne text-xs font-bold uppercase tracking-[0.25em] text-ink transition-colors hover:bg-bone"
              >
                Book an Appointment
              </a>
              <p className="mt-5 text-center text-[10px] uppercase tracking-[0.35em] text-fog">
                {salon.tagline}
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
