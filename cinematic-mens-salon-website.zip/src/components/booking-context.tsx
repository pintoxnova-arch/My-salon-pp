"use client";

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react";

interface BookingContextValue {
  /** Currently preselected service id (from "Book this service"). */
  serviceId: string | null;
  selectService: (id: string | null) => void;
  /** Preselect a service and glide to the booking form. */
  bookService: (id: string) => void;
  /** Smooth-scroll to the booking section. */
  goToBooking: () => void;
}

const BookingContext = createContext<BookingContextValue | null>(null);

export function BookingProvider({ children }: { children: ReactNode }) {
  const [serviceId, setServiceId] = useState<string | null>(null);

  const goToBooking = useCallback(() => {
    const el = document.getElementById("booking");
    if (!el) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    el.scrollIntoView({ behavior: reduce ? "auto" : "smooth" });
  }, []);

  const bookService = useCallback(
    (id: string) => {
      setServiceId(id);
      goToBooking();
    },
    [goToBooking],
  );

  const value = useMemo(
    () => ({ serviceId, selectService: setServiceId, bookService, goToBooking }),
    [serviceId, goToBooking],
  );

  return (
    <BookingContext.Provider value={value}>{children}</BookingContext.Provider>
  );
}

export function useBooking(): BookingContextValue {
  const ctx = useContext(BookingContext);
  if (!ctx) throw new Error("useBooking must be used inside BookingProvider");
  return ctx;
}
