"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import {
  lookbookCategories,
  lookbookDisclaimer,
  lookbookItems,
  type LookbookCategory,
} from "@/data/lookbook";
import GalleryImage from "@/components/gallery-image";
import { LineReveal, Reveal, SectionLabel } from "@/components/motion";

export default function LookbookSection() {
  const [category, setCategory] = useState<LookbookCategory>("All Styles");

  const items = useMemo(
    () =>
      category === "All Styles"
        ? lookbookItems
        : lookbookItems.filter((item) => item.category === category),
    [category],
  );

  return (
    <section
      id="lookbook"
      aria-labelledby="lookbook-heading"
      className="scroll-mt-20 border-t border-line py-24 md:py-36"
    >
      <div className="mx-auto max-w-[1400px] px-5 md:px-10">
        {/* Header */}
        <div className="grid gap-8 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-6">
            <Reveal>
              <SectionLabel>The Lookbook</SectionLabel>
            </Reveal>
            <h2
              id="lookbook-heading"
              className="mt-6 font-display text-[clamp(3rem,7vw,6.2rem)] leading-[0.92] tracking-[0.01em] text-bone"
            >
              <LineReveal lines={["FIND YOUR", "SIGNATURE."]} />
            </h2>
          </div>
          <Reveal delay={0.15} className="lg:col-span-6">
            <p className="max-w-sm text-[15px] leading-relaxed text-fog lg:ml-auto">
              A curated set of cuts and grooming styles. Bring a reference —
              we&apos;ll shape it to suit you.
            </p>
          </Reveal>
        </div>

        {/* Filters */}
        <Reveal delay={0.1}>
          <div
            role="tablist"
            aria-label="Filter styles by category"
            className="mt-12 flex flex-wrap gap-2"
          >
            {lookbookCategories.map((cat) => {
              const isActive = category === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => setCategory(cat)}
                  className={`h-11 px-5 text-[11px] font-bold uppercase tracking-[0.22em] transition-all duration-300 active:scale-[0.97] ${
                    isActive
                      ? "bg-bone text-ink"
                      : "border border-line text-fog hover:border-champagne/60 hover:text-bone"
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </Reveal>

        {/* Gallery */}
        <motion.ul
          layout
          className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-4 lg:grid-cols-4"
          aria-live="polite"
        >
          <AnimatePresence mode="popLayout">
            {items.map((item, index) => (
              <motion.li
                layout
                key={item.id}
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                className={item.featured ? "md:col-span-2 md:row-span-2" : ""}
              >
                <figure className="group relative h-full w-full overflow-hidden">
                  <GalleryImage
                    src={item.image}
                    alt={item.alt}
                    eager={index < 2}
                    className={`w-full transition-transform duration-700 ease-out group-hover:scale-[1.05] ${
                      item.featured
                        ? "aspect-[3/4] md:aspect-auto md:h-full"
                        : "aspect-[3/4]"
                    }`}
                  />
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/10 to-transparent opacity-80 transition-opacity duration-500 group-hover:opacity-100"
                  />
                  <figcaption className="absolute inset-x-0 bottom-0 flex items-end justify-between p-4 md:p-5">
                    <div>
                      <p className="text-[9px] font-semibold uppercase tracking-[0.3em] text-champagne">
                        {item.category}
                      </p>
                      <p className="mt-1.5 font-display text-xl leading-none tracking-[0.05em] text-bone md:text-2xl">
                        {item.title.toUpperCase()}
                      </p>
                    </div>
                    <span
                      aria-hidden="true"
                      className="mb-0.5 hidden size-8 -translate-y-1 place-items-center border border-bone/30 text-[10px] text-bone opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100 md:grid"
                    >
                      {String(index + 1).padStart(2, "0")}
                    </span>
                  </figcaption>
                </figure>
              </motion.li>
            ))}
          </AnimatePresence>
        </motion.ul>

        <Reveal delay={0.1}>
          <p className="mt-8 text-[12px] leading-relaxed text-fog/80">
            {lookbookDisclaimer}
          </p>
        </Reveal>
      </div>
    </section>
  );
}
