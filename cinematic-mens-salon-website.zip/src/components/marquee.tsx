/**
 * Editorial marquee divider — pure CSS animation, duplicated content for a
 * seamless loop, decorative only (aria-hidden). Reduced-motion safe via the
 * global media query.
 */
const WORDS = ["Precision", "Craft", "Detail", "Style", "Discipline"];

function Strip() {
  return (
    <div className="flex shrink-0 items-center">
      {WORDS.map((word, i) => (
        <span key={i} className="flex items-center">
          <span
            className={`whitespace-nowrap px-6 font-display text-[clamp(2.6rem,6vw,5rem)] leading-none tracking-[0.06em] md:px-10 ${
              i % 2 === 0 ? "text-bone/90" : "text-stroke-ghost"
            }`}
          >
            {word.toUpperCase()}
          </span>
          <span className="size-2 rotate-45 bg-champagne/70" aria-hidden="true" />
        </span>
      ))}
    </div>
  );
}

export default function Marquee() {
  return (
    <div
      aria-hidden="true"
      className="relative overflow-hidden border-y border-line py-8 md:py-10"
    >
      <div className="flex w-max animate-marquee">
        <Strip />
        <Strip />
      </div>
    </div>
  );
}
