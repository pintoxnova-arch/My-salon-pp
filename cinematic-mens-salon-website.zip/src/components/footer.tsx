import { InstagramIcon } from "@/components/icons";
import { salon } from "@/data/salon";
import { pricingDisclaimer, services } from "@/data/services";

const NAV = [
  { label: "Home", href: "#home" },
  { label: "Services", href: "#services" },
  { label: "The Lookbook", href: "#lookbook" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#contact" },
];

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-line bg-coal/40">
      <div className="mx-auto max-w-[1400px] px-5 py-16 md:px-10 md:py-20">
        <div className="grid gap-12 md:grid-cols-12">
          {/* Brand */}
          <div className="md:col-span-5">
            <a
              href="#home"
              className="font-display text-4xl tracking-[0.06em] text-bone transition-colors hover:text-champagne"
            >
              {salon.name}
              <sup className="ml-0.5 align-super text-xs text-champagne">®</sup>
            </a>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-fog">
              {salon.supportingLine}
            </p>
            <a
              href="#booking"
              className="mt-8 inline-flex h-12 items-center bg-champagne px-7 text-[10px] font-bold uppercase tracking-[0.25em] text-ink transition-colors duration-300 hover:bg-bone"
            >
              Book an Appointment
            </a>
            {salon.instagram && (
              <a
                href={salon.instagram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="SHARP CUTS on Instagram"
                className="ml-4 inline-grid size-12 place-items-center border border-line text-fog transition-colors duration-300 hover:border-champagne/60 hover:text-champagne"
              >
                <InstagramIcon className="size-4" />
              </a>
            )}
          </div>

          {/* Explore */}
          <nav aria-label="Footer" className="md:col-span-3">
            <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] text-fog">
              Explore
            </h3>
            <ul className="mt-5 space-y-3">
              {NAV.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm text-bone/80 transition-colors duration-300 hover:text-champagne"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* Services */}
          <div className="md:col-span-4">
            <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] text-fog">
              The Menu
            </h3>
            <ul className="mt-5 space-y-3">
              {services.map((service) => (
                <li key={service.id}>
                  <a
                    href="#services"
                    className="group flex items-baseline justify-between gap-4 text-sm text-bone/80 transition-colors duration-300 hover:text-champagne"
                  >
                    {service.name}
                    <span className="text-xs text-fog transition-colors group-hover:text-champagne/80">
                      {service.price}*
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-14 flex flex-col gap-4 border-t border-line pt-7 md:flex-row md:items-center md:justify-between">
          <p className="text-xs text-fog">
            © {year} {salon.nameWithMark} — {salon.tagline}
          </p>
          <p className="max-w-md text-[11px] leading-relaxed text-fog/70">
            *{pricingDisclaimer}
          </p>
        </div>
      </div>
    </footer>
  );
}
