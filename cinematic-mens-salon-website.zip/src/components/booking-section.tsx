"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
  AlertCircle,
  Check,
  ChevronDown,
  Copy,
  Loader2,
  MessageCircle,
  RotateCcw,
  ShieldCheck,
} from "lucide-react";
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { isWhatsAppConfigured, salon } from "@/data/salon";
import { services } from "@/data/services";
import {
  buildAppointmentMessage,
  buildWhatsAppLink,
  formatDateLabel,
  formatSlotLabel,
  generateSlots,
  summaryAsPlainText,
  toDateInputValue,
  validateAppointment,
  type FieldErrors,
  type RequestSummary,
} from "@/lib/booking";
import { useBooking } from "@/components/booking-context";
import { LineReveal, Reveal, SectionLabel } from "@/components/motion";

/* ── Little form primitives ────────────────────────────────────────────── */

function Field({
  label,
  htmlFor,
  error,
  hint,
  children,
}: {
  label: string;
  htmlFor: string;
  error?: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <div>
      <label
        htmlFor={htmlFor}
        className="mb-2 block text-[10px] font-bold uppercase tracking-[0.28em] text-fog"
      >
        {label}
      </label>
      {children}
      {error ? (
        <p id={`${htmlFor}-error`} role="alert" className="mt-2 flex items-center gap-1.5 text-xs text-[#e08b7c]">
          <AlertCircle className="size-3.5 shrink-0" aria-hidden="true" />
          {error}
        </p>
      ) : hint ? (
        <p className="mt-2 text-xs text-fog/70">{hint}</p>
      ) : null}
    </div>
  );
}

const inputClass = (invalid: boolean) =>
  `h-12 w-full border bg-ink px-4 text-sm text-bone placeholder:text-fog/40 transition-colors duration-300 focus:outline-none ${
    invalid
      ? "border-[#e08b7c]/70 focus:border-[#e08b7c]"
      : "border-line focus:border-champagne/70"
  }`;

/* ── The section ───────────────────────────────────────────────────────── */

type Status = "idle" | "submitting" | "success";

export default function BookingSection() {
  const { serviceId, selectService } = useBooking();

  const [form, setForm] = useState({
    name: "",
    phone: "",
    serviceId: "",
    barber: "",
    date: "",
    time: "",
    notes: "",
  });
  const [errors, setErrors] = useState<FieldErrors>({});
  const [status, setStatus] = useState<Status>("idle");
  const [serverError, setServerError] = useState<string | null>(null);
  const [result, setResult] = useState<RequestSummary | null>(null);
  const [resultDuplicate, setResultDuplicate] = useState(false);
  const [booked, setBooked] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);
  const clientToken = useRef<string>(crypto.randomUUID());

  const today = toDateInputValue(new Date());
  const maxDate = toDateInputValue(
    new Date(Date.now() + salon.maxAdvanceDays * 86_400_000),
  );

  /* Service preselection arriving from "Book this service". */
  useEffect(() => {
    if (serviceId) setForm((f) => ({ ...f, serviceId }));
  }, [serviceId]);

  /* Slots for the chosen date + the ones already taken. */
  const slots = useMemo(
    () => (form.date ? generateSlots(form.date) : []),
    [form.date],
  );

  const refreshAvailability = useCallback(async (date: string) => {
    try {
      const res = await fetch(`/api/appointments?date=${encodeURIComponent(date)}`);
      if (!res.ok) throw new Error();
      const data = (await res.json()) as { booked?: string[] };
      setBooked(data.booked ?? []);
    } catch {
      setBooked([]); // fail open — the server still guards conflicts
    }
  }, []);

  useEffect(() => {
    setBooked([]);
    if (form.date) void refreshAvailability(form.date);
  }, [form.date, refreshAvailability]);

  const selectedService = services.find((s) => s.id === form.serviceId);
  const dayIsClosed = form.date !== "" && slots.length === 0;

  const set = (key: keyof typeof form) => (value: string) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key === "serviceId" ? "service" : key]: undefined }));
  };

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setServerError(null);

    const fieldErrors = validateAppointment(
      { ...form, clientToken: clientToken.current },
      { serviceIds: services.map((s) => s.id) },
    );
    if (Object.keys(fieldErrors).length > 0) {
      setErrors(fieldErrors);
      return;
    }
    if (booked.includes(form.time)) {
      setErrors({ time: "That slot was just taken — please pick another time." });
      return;
    }

    setStatus("submitting");
    try {
      const res = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, clientToken: clientToken.current }),
      });
      const data = (await res.json()) as {
        ok?: boolean;
        reference?: string;
        duplicate?: boolean;
        fields?: FieldErrors;
        message?: string;
      };

      if (res.ok && data.ok && data.reference) {
        setResult({
          reference: data.reference,
          name: form.name.trim(),
          phone: form.phone.trim(),
          serviceName: selectedService?.name ?? form.serviceId,
          barber: salon.barberSelection.enabled ? form.barber || undefined : undefined,
          date: form.date,
          time: form.time,
          notes: form.notes.trim() || undefined,
        });
        setResultDuplicate(Boolean(data.duplicate));
        setStatus("success");
        return;
      }
      if (data.fields) {
        setErrors(data.fields);
        if (res.status === 409) void refreshAvailability(form.date);
      } else {
        setServerError(data.message ?? "Something went wrong. Please try again.");
      }
    } catch {
      setServerError(
        "Couldn't reach the booking service. Check your connection and try again.",
      );
    } finally {
      setStatus((s) => (s === "submitting" ? "idle" : s));
    }
  }

  function resetForm() {
    clientToken.current = crypto.randomUUID();
    setForm({ name: "", phone: "", serviceId: "", barber: "", date: "", time: "", notes: "" });
    setErrors({});
    setResult(null);
    setCopied(false);
    setStatus("idle");
    selectService(null);
  }

  async function copySummary() {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(summaryAsPlainText(result));
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(false);
    }
  }

  const whatsappReady = isWhatsAppConfigured();

  return (
    <section
      id="booking"
      aria-labelledby="booking-heading"
      className="scroll-mt-20 border-t border-line py-24 md:py-36"
    >
      <div className="mx-auto max-w-[1400px] px-5 md:px-10">
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-16">
          {/* ── Form / success column ── */}
          <div className="lg:col-span-7">
            <Reveal>
              <SectionLabel>Appointments</SectionLabel>
            </Reveal>
            <h2
              id="booking-heading"
              className="mt-6 font-display text-[clamp(3rem,7vw,6.2rem)] leading-[0.92] tracking-[0.01em] text-bone"
            >
              <LineReveal lines={["REQUEST", "YOUR CHAIR."]} />
            </h2>

            <Reveal delay={0.12}>
              <div className="relative mt-10 border border-line bg-coal/50 p-6 md:p-9">
                <AnimatePresence mode="wait">
                  {status === "success" && result ? (
                    /* ── REQUEST SUMMARY ── */
                    <motion.div
                      key="success"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -12 }}
                      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                      aria-live="polite"
                    >
                      <div className="flex items-start gap-4">
                        <span className="grid size-11 shrink-0 place-items-center border border-champagne/50 text-champagne">
                          <Check className="size-5" aria-hidden="true" />
                        </span>
                        <div>
                          <h3 className="font-display text-3xl tracking-[0.04em] text-bone md:text-4xl">
                            REQUEST RECEIVED
                          </h3>
                          <p className="mt-1.5 text-sm leading-relaxed text-fog">
                            {resultDuplicate
                              ? "You've already sent this request — here are the details again."
                              : "Your request is saved. One last step — send it to the salon so they can confirm your slot."}
                          </p>
                        </div>
                      </div>

                      <p className="mt-8 text-[10px] font-bold uppercase tracking-[0.3em] text-fog">
                        Your reference
                      </p>
                      <p className="mt-1 font-display text-5xl tracking-[0.08em] text-champagne">
                        {result.reference}
                      </p>

                      <dl className="mt-8 grid grid-cols-1 gap-x-8 gap-y-4 border-t border-line pt-6 sm:grid-cols-2">
                        {[
                          ["Name", result.name],
                          ["Phone", result.phone],
                          ["Service", result.serviceName],
                          ...(result.barber ? [["Preferred barber", result.barber] as const] : []),
                          ["Date", formatDateLabel(result.date)],
                          ["Time", formatSlotLabel(result.time)],
                        ].map(([term, value]) => (
                          <div key={term}>
                            <dt className="text-[10px] uppercase tracking-[0.25em] text-fog">{term}</dt>
                            <dd className="mt-1 text-sm text-bone">{value}</dd>
                          </div>
                        ))}
                        {result.notes && (
                          <div className="sm:col-span-2">
                            <dt className="text-[10px] uppercase tracking-[0.25em] text-fog">Notes</dt>
                            <dd className="mt-1 text-sm text-bone">{result.notes}</dd>
                          </div>
                        )}
                      </dl>

                      <div className="mt-9 flex flex-col gap-3">
                        {whatsappReady ? (
                          <a
                            href={buildWhatsAppLink(buildAppointmentMessage(result))}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex h-[52px] items-center justify-center gap-3 bg-champagne px-8 text-[11px] font-bold uppercase tracking-[0.25em] text-ink transition-colors duration-300 hover:bg-bone"
                          >
                            <MessageCircle className="size-4" aria-hidden="true" />
                            Send Request via WhatsApp
                          </a>
                        ) : (
                          <div className="border border-line bg-ink/60 p-5">
                            <p className="text-[11px] font-bold uppercase tracking-[0.25em] text-champagne">
                              WhatsApp handoff pending setup
                            </p>
                            <p className="mt-2 text-[13px] leading-relaxed text-fog">
                              The salon hasn&apos;t connected its WhatsApp number yet,
                              so nothing will be sent automatically. Your request is
                              saved — copy the details and share them once the salon
                              publishes its contact number.
                            </p>
                          </div>
                        )}
                        <div className="flex flex-col gap-3 sm:flex-row">
                          <button
                            type="button"
                            onClick={copySummary}
                            className="inline-flex h-12 flex-1 items-center justify-center gap-2.5 border border-line text-[11px] font-bold uppercase tracking-[0.22em] text-bone transition-colors duration-300 hover:border-champagne/60 hover:text-champagne"
                          >
                            {copied ? <Check className="size-4" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
                            {copied ? "Copied" : "Copy Request Details"}
                          </button>
                          <button
                            type="button"
                            onClick={resetForm}
                            className="inline-flex h-12 flex-1 items-center justify-center gap-2.5 border border-line text-[11px] font-bold uppercase tracking-[0.22em] text-fog transition-colors duration-300 hover:border-bone/40 hover:text-bone"
                          >
                            <RotateCcw className="size-4" aria-hidden="true" />
                            New Request
                          </button>
                        </div>
                      </div>

                      <p className="mt-6 flex items-start gap-2.5 text-[12px] leading-relaxed text-fog/85">
                        <ShieldCheck className="mt-0.5 size-4 shrink-0 text-champagne" aria-hidden="true" />
                        This is a request, not a confirmation — your appointment is
                        only booked once the salon replies and confirms your slot.
                      </p>
                    </motion.div>
                  ) : (
                    /* ── THE FORM ── */
                    <motion.form
                      key="form"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -12 }}
                      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                      onSubmit={onSubmit}
                      noValidate
                      className="grid grid-cols-1 gap-6 sm:grid-cols-2"
                    >
                      <Field label="Full Name" htmlFor="bk-name" error={errors.name}>
                        <input
                          id="bk-name"
                          type="text"
                          autoComplete="name"
                          value={form.name}
                          onChange={(e) => set("name")(e.target.value)}
                          aria-invalid={Boolean(errors.name)}
                          aria-describedby={errors.name ? "bk-name-error" : undefined}
                          placeholder="Your name"
                          className={inputClass(Boolean(errors.name))}
                        />
                      </Field>

                      <Field
                        label="Phone Number"
                        htmlFor="bk-phone"
                        error={errors.phone}
                        hint={`${salon.countryDialCode} · ${salon.phoneHint}`}
                      >
                        <input
                          id="bk-phone"
                          type="tel"
                          inputMode="tel"
                          autoComplete="tel"
                          value={form.phone}
                          onChange={(e) => set("phone")(e.target.value)}
                          aria-invalid={Boolean(errors.phone)}
                          aria-describedby={errors.phone ? "bk-phone-error" : undefined}
                          placeholder="98765 43210"
                          className={inputClass(Boolean(errors.phone))}
                        />
                      </Field>

                      <Field
                        label="Preferred Service"
                        htmlFor="bk-service"
                        error={errors.service}
                        hint={
                          selectedService
                            ? `${selectedService.price} · ${selectedService.duration} · sample price`
                            : undefined
                        }
                      >
                        <div className="relative">
                          <select
                            id="bk-service"
                            value={form.serviceId}
                            onChange={(e) => {
                              set("serviceId")(e.target.value);
                              selectService(e.target.value || null);
                            }}
                            aria-invalid={Boolean(errors.service)}
                            aria-describedby={errors.service ? "bk-service-error" : undefined}
                            className={`${inputClass(Boolean(errors.service))} appearance-none pr-10 ${form.serviceId ? "" : "text-fog/50"}`}
                          >
                            <option value="" disabled>
                              Choose a service
                            </option>
                            {services.map((s) => (
                              <option key={s.id} value={s.id}>
                                {s.name} — {s.price}
                              </option>
                            ))}
                          </select>
                          <ChevronDown className="pointer-events-none absolute right-3.5 top-1/2 size-4 -translate-y-1/2 text-fog" aria-hidden="true" />
                        </div>
                      </Field>

                      {salon.barberSelection.enabled ? (
                        <Field label="Preferred Barber" htmlFor="bk-barber" error={errors.barber} hint="Optional">
                          <div className="relative">
                            <select
                              id="bk-barber"
                              value={form.barber}
                              onChange={(e) => set("barber")(e.target.value)}
                              className={`${inputClass(Boolean(errors.barber))} appearance-none pr-10 ${form.barber ? "" : "text-fog/50"}`}
                            >
                              <option value="">No preference</option>
                              {salon.barberSelection.barbers.map((b) => (
                                <option key={b} value={b}>
                                  {b}
                                </option>
                              ))}
                            </select>
                            <ChevronDown className="pointer-events-none absolute right-3.5 top-1/2 size-4 -translate-y-1/2 text-fog" aria-hidden="true" />
                          </div>
                        </Field>
                      ) : (
                        <Field label="Preferred Date" htmlFor="bk-date" error={errors.date}>
                          <input
                            id="bk-date"
                            type="date"
                            min={today}
                            max={maxDate}
                            value={form.date}
                            onChange={(e) => {
                              set("date")(e.target.value);
                              setForm((f) => ({ ...f, time: "" }));
                            }}
                            aria-invalid={Boolean(errors.date)}
                            aria-describedby={errors.date ? "bk-date-error" : undefined}
                            className={inputClass(Boolean(errors.date))}
                          />
                        </Field>
                      )}

                      {salon.barberSelection.enabled && (
                        <Field label="Preferred Date" htmlFor="bk-date" error={errors.date}>
                          <input
                            id="bk-date"
                            type="date"
                            min={today}
                            max={maxDate}
                            value={form.date}
                            onChange={(e) => {
                              set("date")(e.target.value);
                              setForm((f) => ({ ...f, time: "" }));
                            }}
                            aria-invalid={Boolean(errors.date)}
                            aria-describedby={errors.date ? "bk-date-error" : undefined}
                            className={inputClass(Boolean(errors.date))}
                          />
                        </Field>
                      )}

                      <Field
                        label="Preferred Time"
                        htmlFor="bk-time"
                        error={errors.time}
                        hint={
                          !form.date
                            ? "Select a date first"
                            : dayIsClosed
                              ? "The studio is closed on this day"
                              : undefined
                        }
                      >
                        <div className="relative">
                          <select
                            id="bk-time"
                            value={form.time}
                            disabled={!form.date || dayIsClosed}
                            onChange={(e) => set("time")(e.target.value)}
                            aria-invalid={Boolean(errors.time)}
                            aria-describedby={errors.time ? "bk-time-error" : undefined}
                            className={`${inputClass(Boolean(errors.time))} appearance-none pr-10 ${form.time ? "" : "text-fog/50"}`}
                          >
                            <option value="" disabled>
                              {dayIsClosed ? "Closed" : "Choose a time"}
                            </option>
                            {slots.map((slot) => {
                              const taken = booked.includes(slot);
                              return (
                                <option key={slot} value={slot} disabled={taken}>
                                  {formatSlotLabel(slot)}
                                  {taken ? " — taken" : ""}
                                </option>
                              );
                            })}
                          </select>
                          <ChevronDown className="pointer-events-none absolute right-3.5 top-1/2 size-4 -translate-y-1/2 text-fog" aria-hidden="true" />
                        </div>
                      </Field>

                      <div className="sm:col-span-2">
                        <Field
                          label="Notes or Style Preferences"
                          htmlFor="bk-notes"
                          error={errors.notes}
                          hint="Optional — a reference, a barber's name, anything that helps."
                        >
                          <textarea
                            id="bk-notes"
                            rows={3}
                            maxLength={500}
                            value={form.notes}
                            onChange={(e) => set("notes")(e.target.value)}
                            aria-invalid={Boolean(errors.notes)}
                            aria-describedby={errors.notes ? "bk-notes-error" : undefined}
                            placeholder="e.g. Mid fade, keep the length on top"
                            className={`${inputClass(Boolean(errors.notes))} h-auto resize-none py-3`}
                          />
                        </Field>
                      </div>

                      {serverError && (
                        <p role="alert" className="flex items-center gap-2 text-sm text-[#e08b7c] sm:col-span-2">
                          <AlertCircle className="size-4 shrink-0" aria-hidden="true" />
                          {serverError}
                        </p>
                      )}

                      <div className="sm:col-span-2">
                        <button
                          type="submit"
                          disabled={status === "submitting"}
                          className="inline-flex h-[52px] w-full items-center justify-center gap-3 bg-champagne text-[11px] font-bold uppercase tracking-[0.25em] text-ink transition-all duration-300 hover:bg-bone active:scale-[0.99] disabled:hover:bg-champagne sm:w-auto sm:px-12"
                        >
                          {status === "submitting" && (
                            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                          )}
                          {status === "submitting" ? "Sending Request…" : "Request an Appointment"}
                        </button>
                        <p className="mt-4 flex items-start gap-2.5 text-[12px] leading-relaxed text-fog/85">
                          <ShieldCheck className="mt-0.5 size-4 shrink-0 text-champagne/80" aria-hidden="true" />
                          Your name and phone number are used only to respond to this
                          appointment request — never for marketing, never shared.
                        </p>
                      </div>
                    </motion.form>
                  )}
                </AnimatePresence>
              </div>
            </Reveal>
          </div>

          {/* ── How it works ── */}
          <div className="lg:col-span-5">
            <Reveal delay={0.1}>
              <div className="lg:sticky lg:top-28">
                <h3 className="text-[11px] font-bold uppercase tracking-[0.35em] text-fog">
                  How it works
                </h3>
                <ol className="mt-8 space-y-0">
                  {[
                    {
                      title: "Send your request",
                      copy: "Pick your service, date and time — it takes under a minute.",
                    },
                    {
                      title: "The salon replies",
                      copy: whatsappReady
                        ? "One tap sends your request to the salon's WhatsApp so they see it instantly."
                        : "Your request is saved. Once the salon connects its WhatsApp, you can forward it in one tap.",
                    },
                    {
                      title: "You're confirmed",
                      copy: "Your chair is only booked when the salon confirms. Nothing before that.",
                    },
                  ].map((step, i) => (
                    <li key={step.title} className="relative flex gap-6 border-l border-line pb-10 pl-8 last:pb-0">
                      <span
                        aria-hidden="true"
                        className="absolute -left-px top-0 h-full w-px bg-gradient-to-b from-champagne/60 to-transparent"
                      />
                      <span className="font-display text-2xl leading-none tracking-[0.1em] text-champagne">
                        0{i + 1}
                      </span>
                      <div>
                        <h4 className="font-display text-[1.35rem] leading-tight tracking-[0.04em] text-bone">
                          {step.title.toUpperCase()}
                        </h4>
                        <p className="mt-2 text-[13.5px] leading-relaxed text-fog">
                          {step.copy}
                        </p>
                      </div>
                    </li>
                  ))}
                </ol>

                <div className="mt-12 border border-line p-6">
                  <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-champagne">
                    A note on honesty
                  </p>
                  <p className="mt-3 text-[13px] leading-relaxed text-fog">
                    We never show fake confirmations. A request becomes an
                    appointment only when a real person at the studio says so.
                  </p>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
