"use client";

import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import GalleryImage from "@/components/gallery-image";
import { LineReveal, Reveal, SectionLabel } from "@/components/motion";

const IMG_INTERIOR =
  "https://images.pexels.com/photos/4969838/pexels-photo-4969838.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1400";
const IMG_TOOLS =
  "https://images.pexels.com/photos/13058740/pexels-photo-13058740.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200";

export default function BrandStatement() {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const yLarge = useTransform(scrollYProgress, [0, 1], [50, -50]);
  const ySmall = useTransform(scrollYProgress, [0, 1], [90, -70]);

  return (
    <section
      ref={ref}
      aria-labelledby="brand-heading"
      className="relative overflow-hidden py-24 md:py-40"
    >
      {/* Ghost editorial backdrop */}
      <span
        aria-hidden="true"
        className="text-stroke-ghost pointer-events-none absolute -top-6 left-0 select-none font-display text-[24vw] leading-none tracking-[0.05em]"
      >
        DETAILS
      </span>

      <div className="mx-auto grid max-w-[1400px] gap-16 px-5 md:px-10 lg:grid-cols-12 lg:gap-10">
        {/* Copy */}
        <div className="relative z-10 flex flex-col justify-center lg:col-span-5">
          <Reveal>
            <SectionLabel>More Than a Haircut</SectionLabel>
          </Reveal>
          <h2
            id="brand-heading"
            className="mt-6 font-display text-[clamp(3rem,6.5vw,5.8rem)] leading-[0.92] tracking-[0.01em] text-bone"
          >
            <LineReveal lines={["DETAILS MAKE", "THE DIFFERENCE."]} />
          </h2>
          <Reveal delay={0.15}>
            <p className="mt-7 max-w-md text-[15px] leading-relaxed text-fog md:text-base">
              Your grooming routine should feel considered, personal, and
              effortless. From a clean fade to a carefully shaped beard, every
              detail matters.
            </p>
          </Reveal>
          <Reveal delay={0.25}>
            <a
              href="#services"
              className="group mt-9 inline-flex w-fit items-center gap-3 border-b border-champagne/50 pb-1 text-[11px] font-bold uppercase tracking-[0.3em] text-bone transition-colors duration-300 hover:text-champagne"
            >
              See the Service Menu
              <span
                aria-hidden="true"
                className="transition-transform duration-300 group-hover:translate-x-1.5"
              >
                →
              </span>
            </a>
          </Reveal>
        </div>

        {/* Asymmetric image composition */}
        <div className="relative lg:col-span-7">
          <div className="relative ml-auto w-full max-w-[560px] lg:w-[86%]">
            <motion.div
              style={reduce ? undefined : { y: yLarge }}
              className="relative"
            >
              <div
                aria-hidden="true"
                className="absolute -inset-3 border border-champagne/25 md:-inset-4"
              />
              <GalleryImage
                src={IMG_INTERIOR}
                alt="Warm, minimal interior of a premium grooming studio with leather barber chairs."
                className="aspect-[4/3] w-full"
              />
            </motion.div>
          </div>
          <motion.div
            style={reduce ? undefined : { y: ySmall }}
            className="absolute -bottom-14 left-0 w-[52%] max-w-[300px] md:-bottom-20"
          >
            <GalleryImage
              src={IMG_TOOLS}
              alt="Close-up of a barber's tools laid out on a wooden shelf."
              className="aspect-[4/3] w-full border-4 border-ink shadow-2xl shadow-black/60"
            />
            <p className="mt-3 text-[10px] uppercase tracking-[0.3em] text-fog">
              The tools of the trade
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
